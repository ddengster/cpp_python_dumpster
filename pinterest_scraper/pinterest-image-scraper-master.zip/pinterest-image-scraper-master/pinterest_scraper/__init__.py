try:
    from scraper import Pinterest_Helper, download
except ImportError:
    from .scraper import Pinterest_Helper, download